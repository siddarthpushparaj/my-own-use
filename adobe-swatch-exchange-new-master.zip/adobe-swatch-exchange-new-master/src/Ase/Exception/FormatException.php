<?php
/**
 * Adobe Swatch Exchange Generator
 *
 * @author   Ryan Parman <http://ryanparman.com>
 * @version  2.1
 * @license  MIT
 */

namespace Ase\Exception;

use Exception;

class FormatException extends Exception {}
